# IngestionReport

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**documentId** | **UUID** |  | [optional] 
**source** | **String** |  | [optional] 
**chunksCreated** | [**IngestionReportChunksCreated**](IngestionReportChunksCreated.md) |  | [optional] 
**skipped** | **Bool** |  | [optional] 
**skippedReason** | **String** |  | [optional] 
**replaced** | **Bool** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# Profile

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **UUID** |  | [optional] 
**displayName** | **String** |  | [optional] 
**email** | **String** |  | [optional] 
**locale** | **String** |  | [optional] 
**preferredLanguage** | **String** |  | [optional] 
**responseStyle** | **String** |  | [optional] 
**createdAt** | **Date** |  | [optional] 
**updatedAt** | **Date** |  | [optional] 
**lastSeenAt** | **Date** |  | [optional] 
**reasoningTokensLast7Days** | [**ProfileReasoningTokensLast7Days**](ProfileReasoningTokensLast7Days.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



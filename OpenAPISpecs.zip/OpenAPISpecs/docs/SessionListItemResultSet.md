# SessionListItemResultSet

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**count** | [**IngestionReportChunksCreated**](IngestionReportChunksCreated.md) |  | [optional] 
**items** | [SessionListItem] |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# DocumentsAPI

All URIs are relative to *https://agents.indice.gr*

Method | HTTP request | Description
------------- | ------------- | -------------
[**clear**](DocumentsAPI.md#clear) | **POST** /api/documents/clear | Clears the knowledge base.
[**documentIngest**](DocumentsAPI.md#documentingest) | **POST** /api/documents/ingest | Ingests a document into the knowledge base.


# **clear**
```swift
    open class func clear(completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Clears the knowledge base.

Clears all documents and their chunks from the knowledge base.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient


// Clears the knowledge base.
DocumentsAPI.clear() { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

Void (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **documentIngest**
```swift
    open class func documentIngest(documentType: DocumentType? = nil, category: String? = nil, language: String? = nil, file: URL? = nil, completion: @escaping (_ data: IngestionReport?, _ error: Error?) -> Void)
```

Ingests a document into the knowledge base.

Uploads a single Markdown file and processes it into the knowledge base.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let documentType = DocumentType() // DocumentType |  (optional)
let category = "category_example" // String |  (optional)
let language = "language_example" // String |  (optional)
let file = URL(string: "https://example.com")! // URL |  (optional)

// Ingests a document into the knowledge base.
DocumentsAPI.documentIngest(documentType: documentType, category: category, language: language, file: file) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **documentType** | [**DocumentType**](DocumentType.md) |  | [optional] 
 **category** | **String** |  | [optional] 
 **language** | **String** |  | [optional] 
 **file** | **URL** |  | [optional] 

### Return type

[**IngestionReport**](IngestionReport.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: multipart/form-data, application/x-www-form-urlencoded
 - **Accept**: application/problem+json, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


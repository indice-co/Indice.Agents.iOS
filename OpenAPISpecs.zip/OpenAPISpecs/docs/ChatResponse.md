# ChatResponse

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**sessionId** | **UUID** |  | [optional] 
**messageId** | **UUID** |  | [optional] 
**answer** | **String** |  | [optional] 
**citations** | [Citation] |  | [optional] 
**failed** | **Bool** |  | [optional] 
**failureReason** | **String** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



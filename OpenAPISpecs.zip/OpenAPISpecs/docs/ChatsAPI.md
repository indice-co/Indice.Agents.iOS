# ChatsAPI

All URIs are relative to *https://agents.indice.gr*

Method | HTTP request | Description
------------- | ------------- | -------------
[**create**](ChatsAPI.md#create) | **POST** /api/my/chats | Create a chat session with the first question.
[**delete**](ChatsAPI.md#delete) | **DELETE** /api/my/chats/{chatId} | Delete a chat session and its messages.
[**getChatSession**](ChatsAPI.md#getchatsession) | **GET** /api/my/chats/{chatId} | Get a chat session with its recent messages.
[**list**](ChatsAPI.md#list) | **GET** /api/my/chats | List the caller&#39;s chat sessions, paged.
[**sendMessage**](ChatsAPI.md#sendmessage) | **POST** /api/my/chats/{chatId}/messages | Post a follow-up message to an existing chat session.
[**streamCreate**](ChatsAPI.md#streamcreate) | **POST** /api/my/chats/stream | Create a chat session and stream the first turn over Server-Sent Events.
[**streamMessage**](ChatsAPI.md#streammessage) | **POST** /api/my/chats/{chatId}/messages/stream | Stream a follow-up turn over Server-Sent Events.


# **create**
```swift
    open class func create(chatRequest: ChatRequest, completion: @escaping (_ data: ChatResponse?, _ error: Error?) -> Void)
```

Create a chat session with the first question.

Creates a new chat session for the calling user and runs the first question through the RAG pipeline in one round-trip. Returns 201 with the grounded answer, citations, usage, and the new session id.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let chatRequest = ChatRequest(text: "text_example") // ChatRequest | 

// Create a chat session with the first question.
ChatsAPI.create(chatRequest: chatRequest) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chatRequest** | [**ChatRequest**](ChatRequest.md) |  | 

### Return type

[**ChatResponse**](ChatResponse.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/problem+json, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **delete**
```swift
    open class func delete(chatId: UUID, completion: @escaping (_ data: Void?, _ error: Error?) -> Void)
```

Delete a chat session and its messages.

Permanently deletes the session and all its messages. Returns 204 on success, 404 when the session does not exist for the calling user.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let chatId = 987 // UUID | 

// Delete a chat session and its messages.
ChatsAPI.delete(chatId: chatId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chatId** | **UUID** |  | 

### Return type

Void (empty response body)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/problem+json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **getChatSession**
```swift
    open class func getChatSession(chatId: UUID, completion: @escaping (_ data: Session?, _ error: Error?) -> Void)
```

Get a chat session with its recent messages.

Returns session metadata (title, timestamps, cumulative token totals) plus the most recent messages in chronological order.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let chatId = 987 // UUID | 

// Get a chat session with its recent messages.
ChatsAPI.getChatSession(chatId: chatId) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chatId** | **UUID** |  | 

### Return type

[**Session**](Session.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/problem+json, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **list**
```swift
    open class func list(page: ListPageParameter? = nil, size: ListPageParameter? = nil, sort: String? = nil, search: String? = nil, completion: @escaping (_ data: SessionListItemResultSet?, _ error: Error?) -> Void)
```

List the caller's chat sessions, paged.

Returns a paged list of sessions owned by the caller, ordered by most recent activity.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let page = List_Page_parameter() // ListPageParameter | The current page of the list. Default is 1. (optional)
let size = List_Page_parameter() // ListPageParameter | The size of the list. Default is 100 (optional)
let sort = "sort_example" // String | The sort order plus the sort direction of the list. for example displayName- (optional)
let search = "search_example" // String | A search term used to limit the results of the list. (optional)

// List the caller's chat sessions, paged.
ChatsAPI.list(page: page, size: size, sort: sort, search: search) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **page** | **ListPageParameter** | The current page of the list. Default is 1. | [optional] 
 **size** | **ListPageParameter** | The size of the list. Default is 100 | [optional] 
 **sort** | **String** | The sort order plus the sort direction of the list. for example displayName- | [optional] 
 **search** | **String** | A search term used to limit the results of the list. | [optional] 

### Return type

[**SessionListItemResultSet**](SessionListItemResultSet.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/problem+json, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **sendMessage**
```swift
    open class func sendMessage(chatId: UUID, chatRequest: ChatRequest, completion: @escaping (_ data: ChatResponse?, _ error: Error?) -> Void)
```

Post a follow-up message to an existing chat session.

Loads bounded conversation history, runs the message through the RAG pipeline, persists the user/assistant turn, and returns the grounded answer + cumulative session token totals.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let chatId = 987 // UUID | 
let chatRequest = ChatRequest(text: "text_example") // ChatRequest | 

// Post a follow-up message to an existing chat session.
ChatsAPI.sendMessage(chatId: chatId, chatRequest: chatRequest) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chatId** | **UUID** |  | 
 **chatRequest** | [**ChatRequest**](ChatRequest.md) |  | 

### Return type

[**ChatResponse**](ChatResponse.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/problem+json, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **streamCreate**
```swift
    open class func streamCreate(chatRequest: ChatRequest, completion: @escaping (_ data: SseItemOfChatStreamEvent?, _ error: Error?) -> Void)
```

Create a chat session and stream the first turn over Server-Sent Events.

Streaming counterpart of `POST /api/my/chats`. Creates a session and runs the first question through  the RAG pipeline, emitting `text/event-stream` events as it executes:    - `event: step` — `{ \"type\":\"step\", \"step\":\"Retrieving relevant context\" }` (one per pipeline step).  - `event: delta` — `{ \"type\":\"delta\", \"text\":\"…\" }` (repeated; the answer streamed token-by-token).  - `event: complete` — `{ \"type\":\"complete\", \"sessionId\":\"…\", \"messageId\":\"…\", \"answer\":\"…\", \"citations\":[…], \"failed\":false, \"failureReason\":null }`.    The turn is persisted when the stream completes. (SwaggerUI cannot render SSE — use a streaming client, e.g. `curl -N`.)

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let chatRequest = ChatRequest(text: "text_example") // ChatRequest | 

// Create a chat session and stream the first turn over Server-Sent Events.
ChatsAPI.streamCreate(chatRequest: chatRequest) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chatRequest** | [**ChatRequest**](ChatRequest.md) |  | 

### Return type

[**SseItemOfChatStreamEvent**](SseItemOfChatStreamEvent.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/problem+json, text/event-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **streamMessage**
```swift
    open class func streamMessage(chatId: UUID, chatRequest: ChatRequest, completion: @escaping (_ data: SseItemOfChatStreamEvent?, _ error: Error?) -> Void)
```

Stream a follow-up turn over Server-Sent Events.

Streaming counterpart of `POST /api/my/chats/{chatId}/messages`. Emits `event: step`, then `event: delta`  (answer token-by-token), then a terminal `event: complete` carrying the citations and persisted  `messageId`. Returns 404 before any event is sent when the session does not exist for the caller.  (SwaggerUI cannot render SSE — use a streaming client, e.g. `curl -N`.)

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let chatId = 987 // UUID | 
let chatRequest = ChatRequest(text: "text_example") // ChatRequest | 

// Stream a follow-up turn over Server-Sent Events.
ChatsAPI.streamMessage(chatId: chatId, chatRequest: chatRequest) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **chatId** | **UUID** |  | 
 **chatRequest** | [**ChatRequest**](ChatRequest.md) |  | 

### Return type

[**SseItemOfChatStreamEvent**](SseItemOfChatStreamEvent.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/problem+json, text/event-stream

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


# MyProfileAPI

All URIs are relative to *https://agents.indice.gr*

Method | HTTP request | Description
------------- | ------------- | -------------
[**getMe**](MyProfileAPI.md#getme) | **GET** /api/my/profile | Get the caller&#39;s profile.
[**updateMe**](MyProfileAPI.md#updateme) | **PUT** /api/my/profile | Update the caller&#39;s preferences.


# **getMe**
```swift
    open class func getMe(completion: @escaping (_ data: Profile?, _ error: Error?) -> Void)
```

Get the caller's profile.

Returns the caller's application-local profile, creating it on first access (just-in-time) from the IdP claims. The IdP stays the source of truth for identity; this row holds app-specific preferences plus a cached snapshot of name/email/locale.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient


// Get the caller's profile.
MyProfileAPI.getMe() { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters
This endpoint does not need any parameter.

### Return type

[**Profile**](Profile.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: Not defined
 - **Accept**: application/problem+json, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)

# **updateMe**
```swift
    open class func updateMe(updateUserRequest: UpdateUserRequest, completion: @escaping (_ data: Profile?, _ error: Error?) -> Void)
```

Update the caller's preferences.

Updates the caller's app-specific preferences (preferred answer language, response style). The language is validated against the configured taxonomy — an unknown value returns 400.

### Example
```swift
// The following code samples are still beta. For any issue, please report via http://github.com/OpenAPITools/openapi-generator/issues/new
import OpenAPIClient

let updateUserRequest = UpdateUserRequest(preferredLanguage: "preferredLanguage_example", responseStyle: "responseStyle_example") // UpdateUserRequest | 

// Update the caller's preferences.
MyProfileAPI.updateMe(updateUserRequest: updateUserRequest) { (response, error) in
    guard error == nil else {
        print(error)
        return
    }

    if (response) {
        dump(response)
    }
}
```

### Parameters

Name | Type | Description  | Notes
------------- | ------------- | ------------- | -------------
 **updateUserRequest** | [**UpdateUserRequest**](UpdateUserRequest.md) |  | 

### Return type

[**Profile**](Profile.md)

### Authorization

[oauth2](../README.md#oauth2)

### HTTP request headers

 - **Content-Type**: application/json
 - **Accept**: application/problem+json, application/json

[[Back to top]](#) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to Model list]](../README.md#documentation-for-models) [[Back to README]](../README.md)


# HttpValidationProblemDetails

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | [optional] 
**title** | **String** |  | [optional] 
**status** | [**ListPageParameter**](ListPageParameter.md) |  | [optional] 
**detail** | **String** |  | [optional] 
**instance** | **String** |  | [optional] 
**errors** | [String: [String]] |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



# Citation

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**chunkId** | **UUID** |  | [optional] 
**documentId** | **UUID** |  | [optional] 
**title** | **String** |  | [optional] 
**headingPath** | **String** |  | [optional] 
**score** | [**CitationScore**](CitationScore.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



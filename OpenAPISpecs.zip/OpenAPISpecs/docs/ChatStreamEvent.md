# ChatStreamEvent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**type** | **String** |  | [optional] 
**step** | **String** |  | [optional] 
**text** | **String** |  | [optional] 
**answer** | **String** |  | [optional] 
**citations** | [Citation] |  | [optional] 
**sessionId** | **UUID** |  | [optional] 
**messageId** | **UUID** |  | [optional] 
**failed** | **Bool** |  | [optional] 
**failureReason** | **String** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



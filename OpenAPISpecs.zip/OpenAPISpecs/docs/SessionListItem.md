# SessionListItem

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**id** | **UUID** |  | [optional] 
**title** | **String** |  | [optional] 
**createdAt** | **Date** |  | [optional] 
**lastActivityAt** | **Date** |  | [optional] 
**totalPromptTokens** | [**ProfileReasoningTokensLast7Days**](ProfileReasoningTokensLast7Days.md) |  | [optional] 
**totalCompletionTokens** | [**ProfileReasoningTokensLast7Days**](ProfileReasoningTokensLast7Days.md) |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)



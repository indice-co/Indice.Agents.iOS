# SseItemOfChatStreamEvent

## Properties
Name | Type | Description | Notes
------------ | ------------- | ------------- | -------------
**data** | [**ChatStreamEvent**](ChatStreamEvent.md) |  | [optional] 
**eventType** | **String** |  | [optional] 
**eventId** | **String** |  | [optional] 
**reconnectionInterval** | **String** |  | [optional] 

[[Back to Model list]](../README.md#documentation-for-models) [[Back to API list]](../README.md#documentation-for-api-endpoints) [[Back to README]](../README.md)


